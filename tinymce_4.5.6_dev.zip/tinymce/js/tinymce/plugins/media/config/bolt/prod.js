configure({
  sources: [
    source('amd', 'tinymce.media', '../../src/main/js', mapper.hierarchical)
  ]
});