configure({
  sources: [
		source('amd', 'tinymce.wordcount', '../../src/main/js', mapper.hierarchical)
  ]
});